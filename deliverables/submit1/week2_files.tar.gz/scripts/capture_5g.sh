#!/bin/bash

# 5G network packet capture script
# Capture N2/N3 traffic between free5GC and UERANSIM

INTERFACE="enp0s8"
OUTPUT_DIR="$HOME/5g-week2/pcap"

mkdir -p "$OUTPUT_DIR"

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
OUTPUT_FILE="$OUTPUT_DIR/5g_capture_${TIMESTAMP}.pcap"

echo "========================================"
echo "5G Network Packet Capture"
echo "Interface : $INTERFACE"
echo "Output    : $OUTPUT_FILE"
echo "========================================"
echo "Press Ctrl+C to stop capture."

sudo tcpdump \
    -i "$INTERFACE" \
    -s 0 \
    -nn \
    -w "$OUTPUT_FILE"
